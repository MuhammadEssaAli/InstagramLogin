//
//  ViewController.swift
//  LoginInstagram
//
//  Created by Muhammad Essa Ali on 19/05/2020.
//  Copyright © 2020 Muhammad Essa Ali. All rights reserved.
//

import UIKit
import WebKit
import Alamofire

public protocol WebControllerDelegate: class {
    func instagramLoginDidFinish(accessToken: String?, error: InstagramError?)
}

class WebController: UIViewController , WKNavigationDelegate {
    
    @IBOutlet weak var webView: WKWebView!
    var isUrlValid : Bool = false
    var baseUrl : String?
    var authToken:String = ""
    var userID : Int = 0
    var accessTokenFinal : String = ""
    public weak var delegate: WebControllerDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
         
        webView.navigationDelegate = self
        let url = "https://api.instagram.com/oauth/authorize/?client_id=1893892080735726&redirect_uri=https://instagram.com/&response_type=code&display=touch&scope=user_profile,user_media"
        let req = URLRequest.init(url: URL.init(string: url)!)
        webView.load(req)
        
    }
 
    func serviceCall(urlString : String) {
        
        self.isUrlValid = false
        let accessToken : String = String(authToken.dropLast(97))
        
        let parameter = ["client_id":"1893892080735726", "client_secret": "1a7336563749c8b31db4f26a13bc32f5", "code":accessToken, "grant_type": "authorization_code", "redirect_uri":"https://instagram.com/"]
        
        Alamofire.request(urlString, method: HTTPMethod(rawValue: HTTPMethod.post.rawValue)!, parameters: parameter, encoding: URLEncoding.default)
            .responseJSON { response in
                
                print("Request URL : " + urlString)
                print("Param : ",parameter)
                
                print(response)
                
                switch response.result {
                case .success(let JSON):
                    let object = JSON as? NSDictionary
                    self.userID = object?["user_id"] as! Int
                    self.accessTokenFinal = object?["access_token"] as! String
                    
                    let graphApiUrl = "https://graph.instagram.com/"+"\(self.userID)"+"?fields=id,username&access_token=" + "\(self.accessTokenFinal)"
                    Alamofire.request(graphApiUrl, method: HTTPMethod(rawValue: HTTPMethod.get.rawValue)!, parameters: nil, encoding: URLEncoding.default) .responseJSON { response in
                    
                   print("Request URL : " + urlString)
                    print("Param : ",parameter)
                    
                    print(response)
                    
                    switch response.result {
                    case .success(let JSON):
                        let object = JSON as? NSDictionary
                    print(object)
                    case .failure(let error):
                        print(error)
                       }
                    }
                case .failure(let error):
                    print(error)
                    
                }
        }

    }
    
    public func webView(_ webView: WKWebView,
                        decidePolicyFor navigationAction: WKNavigationAction,
                        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        
        decisionHandler(.allow)
    }

    public func webView(_ webView: WKWebView,
                        decidePolicyFor navigationResponse: WKNavigationResponse,
                        decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {

        if isUrlValid {
            self.serviceCall(urlString: baseUrl ?? "")
        }
        
        
        
        if let response = navigationResponse.response as? HTTPURLResponse, response.statusCode == 200 {
            
           baseUrl = self.trimString(urlString: response.url?.absoluteString ?? "")

        }

        decisionHandler(.allow)
    }
    
    func trimString(urlString : String) -> String {
        
        
        var str:String = ""
        print(urlString)
        if !(urlString.contains("user_profile,user_media")) {
            let st = urlString.replacingOccurrences(of: "https://www.instagram.com/?code=", with: "")
            let st2 = st.replacingOccurrences(of: "#_", with: "")
            let access_token = st2.replacingOccurrences(of: "https://l.instagram.com/?u=https%3A%2F%2Finstagram.com%2F%3Fcode%3D", with: "")
            authToken = access_token
            isUrlValid = true
            str =  "https://api.instagram.com/oauth/access_token/"

            print(str)
        }
        return str
    }
}

