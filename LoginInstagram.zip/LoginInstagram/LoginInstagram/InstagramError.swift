//
//  InstagramError.swift
//  LoginInstagram
//
//  Created by Muhammad Essa Ali on 20/05/2020.
//  Copyright © 2020 Muhammad Essa Ali. All rights reserved.
//

import Foundation
public struct InstagramError: Error {

    // MARK: - Properties

    let kind: ErrorKind
    let message: String

    /// Retrieve the localized description for this error.
    public var localizedDescription: String {
        return "[\(kind.description)] - \(message)"
    }

    // MARK: - Types

    enum ErrorKind: CustomStringConvertible {
        case invalidRequest

        var description: String {
            switch self {
            case .invalidRequest:
                return "invalidRequest"
            }
        }
    }

}
